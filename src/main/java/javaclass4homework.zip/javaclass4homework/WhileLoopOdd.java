package javaclass4homework;

public class WhileLoopOdd {
    public static void main(String[]args){
        int m = 1;
        int n = 1;
        while(m<=10){
            System.out.println(n);
            m+=1;
            n+=2;

        }


        }
    }


