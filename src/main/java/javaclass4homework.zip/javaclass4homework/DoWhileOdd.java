package javaclass4homework;

public class DoWhileOdd {

public static void main(String[]args){
    {
        int m =1;
        System.out.println(" Odd number ");

        do {

            if(m % 2 != 0) {
                System.out.println(" " + m);
            }
            m++;

        } while (m <= 20);




    }
}

}
