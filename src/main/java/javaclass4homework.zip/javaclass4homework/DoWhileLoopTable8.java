package javaclass4homework;

public class DoWhileLoopTable8 {
    public static void main(String[] args) {
        int n = 1;
        int n1 = 8;

        System.out.println("Table of eight");

        do {

            System.out.println(n1 + " * " + n + " = " + (n1 * n));
            n++;

        } while (n <= 10);

            }
        }




