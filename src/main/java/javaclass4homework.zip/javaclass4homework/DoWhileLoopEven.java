package javaclass4homework;

public class DoWhileLoopEven {
    public static void main(String[] args) {
        int m =1;
        System.out.println(" Even number ");

        do {

       if(m % 2 == 0) {
           System.out.println(" " + m);
       }
            m++;

        } while (m <= 10);




    }
}
