package javaclass4homework;

public class ForLoopeven {
    public static void main(String[]args){

        int a = 10;
        for(int i =1; i<=a; i++){
            if(i % 2 == 0){
                System.out.print(i +" ");
            }
        }

    }
}
