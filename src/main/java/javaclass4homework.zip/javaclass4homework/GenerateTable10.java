package javaclass4homework;

public class GenerateTable10 {
    public static void main(String[]args){
        int i = 10;
        for(int a=0; a<=10; a++){

            System.out.println(i+" * "+ a +" = " + (i*a));

        }

    }
}
