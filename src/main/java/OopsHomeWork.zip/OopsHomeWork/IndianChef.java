package OopsHomeWork;

public class IndianChef extends Chef {
    public void makeindiancurry() {
        System.out.println("the chef make pav bhaji");
    }

    public void makepaneer() {
        System.out.println("the chef make panner bhurji");
    }

    public void makehealthfood() {
        System.out.println("the chef make paratha");
    }

    public void sweet() {
        System.out.println("the chef cook jalebi");
    }
}

