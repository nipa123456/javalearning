package OopsHomeWork;

public class ConceptChef {
    public static void main(String[]args){
        ItalianChef bestchef  =new ItalianChef();
        bestchef.makePasta();

        IndianChef bestchef1  =new IndianChef();
        bestchef1.makepaneer();

        Chef bestchef2  =new Chef();
        bestchef2.makeSpecialdish();




    }
}
