package OopsHomeWork;

public class ItalianChef extends Chef{

    public void makePasta() {
    System.out.println("the chef make pasta");
}

    public void makebeef() {
        System.out.println("the chef make beef");
    }

    public void makehealthfood() {
        System.out.println("the chef make pizza");
    }

    public void cookfish() {
        System.out.println("the chef cook fishcakes");
    }
}


