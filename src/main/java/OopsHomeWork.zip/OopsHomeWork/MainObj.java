package OopsHomeWork;

public class MainObj {

    int x = 5;
    int y =20;

    public static void main(String[] args) {
        MainObj mytv1 = new MainObj();
        MainObj mytv2 = new MainObj();
        System.out.println(mytv1.x);
        System.out.println(mytv2.y);
    }
}



