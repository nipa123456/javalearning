package OopsHomeWork;

public class Chef{
    public void chicken() {
        System.out.println("The chef make chicken");
    }

        public void makeSpecialdish() {
            System.out.println("The chef make pizza");
        }

    public void makehealthfood() {
        System.out.println("The chef make healthyfood");
    }

                public void cookfish() {
                    System.out.println("The chef cook fish");
                }
                }





