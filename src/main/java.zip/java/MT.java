package com.nopcommerce.homepage;

public class MT {




        public static void mail(String[] args) {

            System.out.println("Manualtesting Topic");

            System.out.println("Manual testing" + "Sotware Risk" + "Benefits Of Software" + "Who Does Software Testing" +
                    "Qualification Of Tester" + "What is Manual Testing" + "STCL" + "SDCL");

            System.out.println("Disadvantage Of Manual Testiin" + "Principal Of Software Testing" + "Test Plan And Benefits" +
                    "Test Plan Template" + "Test Case-Template" + "Test Scenario Vs Test Case" + "Test Techniques");

            System.out.println("What Is Bug" + "Bug Lifecylce" + "Template" + "Saverity Vs Priority" + "Testing Lavels");

            System.out.println("Whitebox Testing" + "Blackbox Testing" + "Static Vs Dynamic Testing" + "Software Development Model" + "Iterative" + "V Model" + "Verification And Validation");

            System.out.println("Agile" + "TDD-BDD" + " Defination Of Done" + "Exploratory And AdHoc Testing");

        }
    }

