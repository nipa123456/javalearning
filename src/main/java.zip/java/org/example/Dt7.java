package org.example;

public class Dt7 {


    public static void main(String[] args) {


        char a = 65;
        char b = 66;
        char c = 67;

        System.out.println(a);



    }
}
