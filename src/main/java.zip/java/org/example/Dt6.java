package org.example;

public class Dt6 {

    public static void main(String[] args) {
        float num = 10.3f;
        System.out.println(num);
    }
}





