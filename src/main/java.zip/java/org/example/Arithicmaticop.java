package org.example;

public class Arithicmaticop {
    public static void main(String[] args) {
        int a = 20;
        int b = 40;
        int result1;
        int result2;
        //addition operator
        System.out.println(a + b);

        //subtraction operator
        System.out.println(a - b);

        //multiplication operator
        System.out.println(a * b);

        //division  operator
        System.out.println(a / b);

        //modul operator
        System.out.println(a % b);

        //increment operator
        result1 = ++a;
        System.out.println("After increment: " + a);

        //decrement operator
        result2 = --b;

        System.out.println("After decrement:" + b);
    }






}
