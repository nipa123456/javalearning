package org.example;

public class Dt4 {
// long num = 12000000L;



    public static void main(String[] args) {

        System.out.println(12000000L);
    }
}

