package org.example;

public class Dt3 {
    //class num
    int num = 12345;
       public static void main(String[]args){
           System.out.println("num");
       }
}
