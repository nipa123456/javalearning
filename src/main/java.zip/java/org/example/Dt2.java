package org.example;

public class Dt2 {
    //class short{
    public static void main(String[] args) {


    short n = 2234;

    System.out.println(n);

        }
    }
