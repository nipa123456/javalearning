package org.example;

public class Dt5 {
    // Double num =34345D;
    public static void main(String[] args) {
        Double num =34345D;
     System.out.println(num);
    }
}

