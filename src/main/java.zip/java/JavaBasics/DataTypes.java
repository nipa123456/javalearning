package JavaBasics;

public class DataTypes {

public static void main(String[]args) {
    int X = 19;
    int Y = 18;

    //System.out.println("18>15");

    if (X>Y)
        System.out.println("X is greater then Y");
    else if (X<Y)
        System.out.println("X is less then Y");
    }
}

