public class Evenodd {
    public static void main(String []args){

        int num = 13;

        if (num % 2 == 0) {
            System.out.println("even");
        } else{
            System.out.println("odd");
        }
    }
}
