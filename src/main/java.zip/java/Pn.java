public class Pn {
    public static void main(String[]args){
        int P=-1;
        int N=0;
        if(P>N){
            System.out.println("P is positive");

        } else if(P<N){
            System.out.println("N is negative");
        }else{
            System.out.println("zero number");
        }
    }
}
